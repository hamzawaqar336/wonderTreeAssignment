const express=require("express");
const app=express();
const hbs=require('hbs');
const async = require("hbs/lib/async");
require('./db/conn');
const path=require("path");
const cors=require("cors");
const SubScore=require("./models/SubScore");
//middlewares...>>>
app.use(express.urlencoded({extended:false}))
app.use(express.json())
const templatepath=path.join(__dirname,"../templates/views")
const partials=path.join(__dirname,"../templates/partials")
const StudentList=require("./models/StudentList");
const Subjects=require('./models/Subjects');
app.set('view engine','hbs');
app.set('views',templatepath);
hbs.registerPartials(partials);
//

app.post("/StudentList",async (req,res)=>{
   try{
      const studata=new StudentList({
        StuId:req.body.stuid,
        StuName:req.body.stuname,
        RollNo:req.body.sturollno,
        Gender:req.body.stugender,
      }) 
    const savedata=await studata.save();
 
     
    res.status(201).json({message:"Student Data added successfull"})
   }catch(err){
      console.log(err)
   }
})


app.get("/getStudentList",async (req,res)=>{
    try{
          const findstudata=await StudentList.find({});
          
        //   res.render("index",{
        //       findstudata,findthreedata
        //   })
                    
        res.send(findstudata);



    }catch(err){
         console.log(err)
    }
})
app.get("/getTopthree",async (req,res)=>{
    
    const findthreedata=await SubScore.find({}).sort({"Score":-1}).limit(3)
    
    res.send(findthreedata)
})
app.post("/SubScore",async(req,res)=>{
const date=new Date();
    try{
     const subjectsc=new SubScore({
        StuId:req.body.studentid,
        SubjId:req.body.subjectid,
        Score:req.body.studentscore,
        Time:date.getDate(),
     })
     const savesubject=await subjectsc.save()
     res.status(201).json({message:"Student Data added successfull"})

    }catch(err){
  console.log(err)
    }
})




app.patch("/SubScore/:id",async(req,res)=>{
    try{

        const id=req.params.id; 
        const result=await SubScore.findByIdAndUpdate(id,req.body,{
            new:true
        });
        res.send(result);
     }catch(err){
         res.status(404).send(err)
     }
})

app.delete("/SubScore/:id",async(req,res)=>{
    try{
        const id=req.params.id;
       
       
        const result =await SubScore.findByIdAndDelete(id);
        res.send("your this data is deleted" +result);
    }catch(err){
        res.send(err)
    }
})

app.get("/SubScore",async(req,res)=>{
    try{
  
        const finddata=await SubScore.find({});
        res.send("your all subject score data is "+finddata)

    }catch(err){
       console.log(err)
    }
})

app.get("/SubScore/:id",async(req,res)=>{
    try{
      const id=req.params.id;
      const result=await SubScore.findById(id)
      res.send(result)
    }catch(err){

    }
})

app.post("/Subject",async(req,res)=>{
    try{
     const subdata=new Subjects({
        SubjectId:req.body.subjectid,
        NameOfSubject:req.body.nameos,
     })
     const savesubdata=await subdata.save();
      res.send("your data of subject is save")

    }catch(err){
        console.log(err)
    }
})

app.listen(8007,()=>{
    console.log("server is running")
})

