const mon=require("mongoose")

mon.connect("mongodb://localhost:27017/WonderTreeInterview").then(()=>{
    console.log("db connection is ok")
}).catch((err)=>{
    console.log(err)
})