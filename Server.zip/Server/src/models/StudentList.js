const mon=require("mongoose");

const StuList=new mon.Schema({
    StuId:{type:Number},
    StuName:{type:String},
    RollNo:{type:Number},
    Gender:{type:String}
})

const StudentList= mon.model("StudentList",StuList);

module.exports=StudentList;