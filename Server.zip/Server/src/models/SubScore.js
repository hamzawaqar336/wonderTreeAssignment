const mon=require("mongoose");

const SubScore=new mon.Schema({
   StuId:{type:Number},
   SubjId:{type:Number},
   Score:{type:String},
   Time:{type:String}
})

const SubjectScore= mon.model("SubjectScore",SubScore);

module.exports=SubjectScore;