const mon=require("mongoose");

const Subject=new mon.Schema({
    SubjectId:{type:Number},
    NameOfSubject:{type:String}
})

const Subjects= mon.model("Subjects",Subject);

module.exports=Subjects;