import React from 'react'
import Subject from './Subject'
import Score from './Score'
import { useState } from 'react'

const Studentregister = () => {

  const [rdata,newrdata]=useState({
    stuid:"", stuname:"",sturollno:"",stugender:""
});

let name,value;
const handleinput=(e)=>{
     name=e.target.name;
     value=e.target.value;

     newrdata({...rdata,[name]:value})
}

const postData=async (e)=>{
e.preventDefault();
const { stuid,stuname,sturollno,stugender} = rdata;
const res=await fetch("/StudentList",{
    method:"post",
    headers:{
        "Content-Type":"application/json"
    },
    body:JSON.stringify({
      stuid,stuname,sturollno,stugender
    })
})
 const data=await res.json();
 console.log(data)
 if(!data){
     window.alert("invalid register")
 }else{
     window.alert("register successfull");
    
 }
}


  return (
    <div>
      <h1>Register Student</h1>
      <form id="register-form" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Student Id</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name='stuid' aria-describedby="idHelp" onChange={handleinput} value={rdata.stuid} placeholder='Enter Student Id' />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Student Name</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name='stuname' onChange={handleinput} value={rdata.stuname} placeholder='Enter Student name' />
  </div>
   
  <div class="form-group">
    <label for="exampleInputPassword1">Student RollNo</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name='sturollno' onChange={handleinput} value={rdata.sturollno} placeholder='Enter Student Roll no' />
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Student Gender</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name='stugender' onChange={handleinput} value={rdata.stugender} placeholder='Enter Student Gender' />
  </div>

  <button onClick={postData} type="submit" class="btn btn-primary">Submit</button>
</form>

   <br />
   <h1>Subject Details</h1>
   {<Subject/>}
   <br />
   <h1>Score OF Student</h1>
   <br />
   {<Score/>}
    </div>
  )
}

export default Studentregister
