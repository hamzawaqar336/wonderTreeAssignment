import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router-dom';

const Main = () => {
  const history =useNavigate()
  const [newdata,setdata] = useState({});
  
  const callAllStudentsData=async () =>{
    try{

    const res=await fetch('/getStudentList',{
      method:"GET",
      headers:{
        Accept:"application/json",
      'Content-Type':'application/json'
      },
      credentials:"include"
    });
    const data=await res.json();

    setdata(data)
    
    if(!res.status === 200){
      const error=new Error(res.error)
      throw error
    }



    }catch(err){
      console.log(err)
    }
  }
  useEffect(()=>{
    callAllStudentsData()
  },[]);

// const AllStudData=(val)=>{
//   return(
//     <>
//     <p>{val.StuId}</p>
//     </>
//   )
// }

var tifOptions = Object.keys(newdata).map(function(key) {
    return <option value={"StuId"}>{newdata[key.StuId]}</option>
});

  return (
    <div>
     <h1>Welcome to our main information page</h1>
     <div className="container">
       <div className="row">
         <div className="col-6">
             <h2>Total Number Of Students</h2>
             <p>{tifOptions}</p>
         </div>
         <div className="col-6">
            <h2>Top 3 Performing Students</h2>


         </div>
       </div>
       <div className="row">
         <div className="col-6">
             <h2>Graph of gender ratio of student</h2>


         </div>
         <div className="col-6">
            <h2>Graph of top subject with test</h2>


         </div>
       </div>
     </div>
    </div>
  )
}

export default Main
