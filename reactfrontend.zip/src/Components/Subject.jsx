import React,{useState} from 'react'

const Subject = () => {



    const [rdata,newrdata]=useState({
        subjectid:"", nameos:""
    });
    
    let name,value;
    const handleinput=(e)=>{
         name=e.target.name;
         value=e.target.value;
    
         newrdata({...rdata,[name]:value})
    }
    
    const postData=async (e)=>{
    e.preventDefault();
    const { subjectid,nameos} = rdata;
    const res=await fetch("/Subject",{
        method:"post",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({
          subjectid,nameos
        })
    })
     const data=await res.json();
     console.log(data)
     if(!data){
         window.alert("invalid register")
     }else{
         window.alert("register successfull");
        
     }
    }
    




  return (
    <div>
      <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Subject Id</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name='subjectid' onChange={handleinput} value={rdata.subjectid} aria-describedby="emailHelp" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Name Of Subject</label>
    <input type="text" class="form-control" name='nameos' onChange={handleinput} value={rdata.nameos} id="exampleInputPassword1"  />
  </div>
  <button type="submit"  onClick={postData} class="btn btn-primary">Submit</button>
</form>
    </div>
  )
}

export default Subject
