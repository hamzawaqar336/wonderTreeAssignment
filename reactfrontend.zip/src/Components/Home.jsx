import React from 'react'
import "../home.css"

const Home = () => {
  return (
    <>
   <body id='hhs'>
<div class="container">
	<h1>Welcome To WonderTree</h1>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod anim id est laborum.</p>
	
</div>
</body>
      </>
  )
}

export default Home
