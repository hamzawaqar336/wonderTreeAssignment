import React,{useState} from 'react'

const Score = () => {


    const [rdata,newrdata]=useState({
        studentid:"",subjectid:"",studentscore:""
    });
    
    let name,value;
    const handleinput=(e)=>{
         name=e.target.name;
         value=e.target.value;
    
         newrdata({...rdata,[name]:value})
    }
    
    const postData=async (e)=>{
    e.preventDefault();
    const { studentid,subjectid,studentscore} = rdata;
    const res=await fetch("/SubScore",{
        method:"post",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({
          studentid,subjectid,studentscore
        })
    })
     const data=await res.json();
     console.log(data)
     if(!data){
         window.alert("invalid register")
     }else{
         window.alert("register successfull");
        
     }
    }
    
    

    return (
    <div>
      <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Student Id</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name='studentid' onChange={handleinput} value={rdata.studentid} aria-describedby="emailHelp" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Subject Id</label>
    <input type="number" name='subjectid' class="form-control" onChange={handleinput} value={rdata.subjectid} id="exampleInputPassword1" />
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Score</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name='studentscore' onChange={handleinput} value={rdata.studentscore} aria-describedby="emailHelp" />
  </div>
  <button onClick={postData} type="submit" class="btn btn-primary">Submit</button>
</form>
    </div>
  )
}

export default Score
