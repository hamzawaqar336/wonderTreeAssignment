import React from 'react'

const Display = (props) => {
  return (
    <div>
      <table>
          <thead>
              <tr>
                  <th>Student ID</th>
                  <th>Student name</th>
                  <th>Student Roll No</th>
                  <th>Gender</th>
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>{props.StuId}</td>
                  <td>{props.StuName}</td>
                  <td>{props.RollNo}</td>
                  <td>{props.Gender}</td>
              </tr>
          </tbody>
      </table>
    </div>
  )
}

export default Display
