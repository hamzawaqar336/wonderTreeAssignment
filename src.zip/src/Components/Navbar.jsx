import React from 'react'
import { NavLink } from 'react-router-dom'
import Navlinks from './Navlinks'
import { Route,Routes } from "react-router-dom";
import Home from './Home'
import Main from './Main';
import AboutUs from './AboutUs'
import Studentregister from './Studentregister';

const Navbar = () => {
  return (
    <div>
      <Navlinks />
      <Routes>
     
        <Route exact path='/home' element={<Home />} /> 
        <Route exact path='/about' element={<AboutUs/>} />
        <Route exact path='/sturegister' element={<Studentregister />} /> 
        <Route exact path='/main' element={<Main/>} />

       
       
        
        <Route element={<Error/>} />
       
        
      </Routes>
    </div>
  )
}

export default Navbar
