import React from 'react'

const Topthree = (props) => {
  return (
    <div>
    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Subject ID</th>
                <th>Score</th>
                <th>Time</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{props.StuId}</td>
                <td>{props.SubjId}</td>
                <td>{props.Score}</td>
                <td>{props.Time}</td>
            </tr>
        </tbody>
    </table>
  </div>
  )
}

export default Topthree
