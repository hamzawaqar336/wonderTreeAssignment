import React from 'react'
import '../about.css'
const AboutUs = () => {
  return (
   <>
  <div className="about">
    <div className="upper">
      <div className="logo">
        <img src="" alt="Your logo if any or remove this section" id="logo" />
        <div className="image">
          <div className="camp">
            <img src="https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/78235/tent-clipart-md.png" alt="Image" id="tent" />
            <img src="https://thumbs.gfycat.com/LinedGoldenKentrosaurus-max-1mb.gif" alt="Image" id="fire" />
          </div>
        </div>
      </div>
      <div className="info">
        <h1>ABOUT WonderTree</h1>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque
          nostrum excepturi unde eveniet delectus? Porro esse laudantium hic
          ipsam sed inventore, aliquid quidem tempora rem harum quasi quia
          corrupti dignissimos?
        </p>
      </div>
    </div>
    <div className="lower">
      <div className="info" id="lower-info">
        <h1>ABOUT OUR TEAM</h1>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque
          nostrum excepturi unde eveniet delectus? Porro esse laudantium hic
          ipsam sed inventore, aliquid quidem tempora rem harum quasi quia
          corrupti dignissimos?
        </p>
      </div>
      <div className="slider" id="lower-img">
        <img src="https://i.pinimg.com/736x/6d/7d/b3/6d7db3a1037c8ac5b41b0ebfec293ca4.jpg" alt="Image" id="slider" />
      </div>
    </div>
  </div>
   </>
  )
}

export default AboutUs
