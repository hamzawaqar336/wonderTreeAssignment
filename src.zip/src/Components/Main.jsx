import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router-dom';
import Display from './Display';
import Topthree from './Topthree';
import BarChart from './BarChart';
const Main = () => {
  const history =useNavigate()
  const [newdata,setdata] = useState({});
  const [threedata,newthreedata]= useState({});
  const callAllStudentsData=async () =>{
    try{

    const res=await fetch('/getStudentList',{
      method:"GET",
      headers:{
        Accept:"application/json",
      'Content-Type':'application/json'
      },
      credentials:"include"
    });
    const data=await res.json();

    setdata(data)

    if(!res.status === 200){
      const error=new Error(res.error)
      throw error
    }
    }catch(err){
      console.log(err)
    }
  }
  
  const callTopthreeStudentsData=async () =>{
    try{

    const res=await fetch('/getTopthree',{
      method:"GET",
      headers:{
        Accept:"application/json",
      'Content-Type':'application/json'
      },
      credentials:"include"
    });
    const data=await res.json();

    newthreedata(data)
    if(!res.status === 200){
      const error=new Error(res.error)
      throw error
    }
    }catch(err){
      console.log(err)
    }
  }
  useEffect(()=>{
    callAllStudentsData(),callTopthreeStudentsData()
  },[]);


let students=[]

for(var i=0; i<newdata.length; i++){
  students.push(newdata[i])
}

let topthree=[]
for(var u=0;u<threedata.length;u++){
  topthree.push(threedata[u])
}


const renderstudents=(val) =>{
  return(
    <>
    <Display StuId={val.StuId} StuName={val.StuName} RollNo={val.RollNo} Gender={val.Gender} />
    </>
  )
}
const renderthree=(val) =>{
  return(
    <>
    <Topthree StuId={val.StuId} SubjId={val.SubjId} Score={val.Score} Time={val.Time} />
    </>
  )
}


  return (
    <div>
     <h1>Welcome to our main information page</h1>
     <div className="container">
       <div className="row">
         <div className="col-6">
             <h2>Total Number Of Students</h2>
             <p>
               {students.map(renderstudents)}
             </p>
         </div>
         <div className="col-6">
            <h2>Top 3 Performing Students</h2>
              {topthree.map(renderthree)}

          

         </div>
       </div>
       <div className="row">
         <div className="col-6">
             <h2>Graph of gender ratio of student</h2>
             <BarChart />

         </div>
         <div className="col-6">
            <h2>Graph of top subject with test</h2>
             <BarChart/>

         </div>
       </div>
     </div>
    </div>
  )
}

export default Main
